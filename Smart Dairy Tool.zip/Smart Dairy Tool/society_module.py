import tkinter as tk
import sqlite3

def open_members():
    win = tk.Toplevel()
    win.title("Members")

    name = tk.Entry(win)
    name.pack()
    name.insert(0, "Name")

    phone = tk.Entry(win)
    phone.pack()
    phone.insert(0, "Phone")

    address = tk.Entry(win)
    address.pack()
    address.insert(0, "Address")

    def save():
        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()
        cur.execute("INSERT INTO members(name, phone, address) VALUES (?,?,?)",
                    (name.get(), phone.get(), address.get()))
        conn.commit()
        conn.close()

    tk.Button(win, text="Save", command=save).pack()
import tkinter as tk
import sqlite3

def get_rate(fat, snf):
    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()

    cur.execute("SELECT rate FROM rate_chart WHERE fat=? AND snf=?",
                (fat, snf))
    r = cur.fetchone()
    conn.close()

    return float(r[0]) if r else 0

def open_milk_collection():

    win = tk.Toplevel()
    win.title("Milk Entry")

    date = tk.Entry(win)
    date.pack()
    date.insert(0, "Date")

    member = tk.Entry(win)
    member.pack()
    member.insert(0, "Member ID")

    milk = tk.Entry(win)
    milk.pack()
    milk.insert(0, "Milk")

    fat = tk.Entry(win)
    fat.pack()
    fat.insert(0, "Fat")

    snf = tk.Entry(win)
    snf.pack()
    snf.insert(0, "SNF")

    def save():
        f = float(fat.get())
        s = float(snf.get())

        rate = get_rate(f, s)
        amount = float(milk.get()) * rate

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()
        cur.execute("""
        INSERT INTO milk(date, member_id, milk, fat, snf, rate, amount)
        VALUES (?,?,?,?,?,?,?)
        """, (date.get(), member.get(), milk.get(), f, s, rate, amount))

        conn.commit()
        conn.close()

    tk.Button(win, text="Save", command=save).pack()
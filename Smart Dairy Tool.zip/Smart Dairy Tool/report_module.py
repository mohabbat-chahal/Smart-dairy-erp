import tkinter as tk
import sqlite3

def milk_summary():
    win = tk.Toplevel()
    win.title("Milk Summary")

    text = tk.Text(win)
    text.pack()

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM milk")
    rows = cur.fetchall()
    conn.close()

    for r in rows:
        text.insert(tk.END, str(r) + "\n")
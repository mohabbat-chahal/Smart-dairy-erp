import tkinter as tk
from tkinter import ttk
import sqlite3

def open_farmer_list():

    win = tk.Toplevel()
    win.title("Farmer List")
    win.geometry("600x400")

    tree = ttk.Treeview(win, show="headings")
    tree.pack(fill="both", expand=True)

    tree["columns"] = ("ID","Name","Phone","Address")

    for col in tree["columns"]:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM members")
    rows = cur.fetchall()
    conn.close()

    for r in rows:
        tree.insert("", "end", values=r)
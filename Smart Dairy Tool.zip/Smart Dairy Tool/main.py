import customtkinter as ctk
from datetime import datetime
import tkinter as tk
from tkinter import ttk
import sqlite3

# -------- IMPORT MODULES --------
import database
import rate_chart

# -------- APP SETTINGS --------
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# -------- DATABASE --------
database.connect_db()

# -------- MAIN APP --------
app = ctk.CTk()
app.geometry("1400x800")
app.title("Smart Dairy ERP")

# =========================================================
# MAIN LAYOUT
# =========================================================

# -------- SIDEBAR --------
sidebar = ctk.CTkFrame(app, width=220, corner_radius=0)
sidebar.pack(side="left", fill="y")

# -------- RIGHT SIDE --------
right_container = ctk.CTkFrame(app)
right_container.pack(side="right", expand=True, fill="both")

# -------- TOP HEADER --------
header = ctk.CTkFrame(right_container, height=70)
header.pack(fill="x", padx=10, pady=10)

# -------- CONTENT AREA --------
content = ctk.CTkFrame(right_container)
content.pack(expand=True, fill="both", padx=10, pady=(0,10))

# =========================================================
# HEADER CONTENT
# =========================================================

title = ctk.CTkLabel(
    header,
    text="🐄 Smart Dairy ERP",
    font=("Arial", 28, "bold")
)
title.pack(side="left", padx=20)

search = ctk.CTkEntry(
    header,
    placeholder_text="Search..."
)
search.pack(side="left", padx=20)

user_label = ctk.CTkLabel(
    header,
    text="👤 Admin",
    font=("Arial", 16)
)
user_label.pack(side="right", padx=20)

date_label = ctk.CTkLabel(
    header,
    text=datetime.now().strftime("%d-%m-%Y"),
    font=("Arial", 16)
)
date_label.pack(side="right", padx=20)

# =========================================================
# SIDEBAR TITLE
# =========================================================

logo = ctk.CTkLabel(
    sidebar,
    text="🐄 Dairy ERP",
    font=("Arial", 26, "bold")
)
logo.pack(pady=30)

# =========================================================
# PAGE SWITCHING
# =========================================================

def clear_content():
    for widget in content.winfo_children():
        widget.destroy()

# =========================================================
# DASHBOARD PAGE
# =========================================================

def open_dashboard():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Dashboard",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

    cards_frame = ctk.CTkFrame(content)
    cards_frame.pack(fill="x", padx=20, pady=20)

    # Total Milk
    card1 = ctk.CTkFrame(cards_frame, width=200, height=120)
    card1.pack(side="left", padx=20)

    ctk.CTkLabel(
        card1,
        text="🥛 Total Milk",
        font=("Arial", 18)
    ).pack(pady=10)

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()

    cur.execute("SELECT SUM(milk) FROM milk")
    milk_total = cur.fetchone()[0]

    conn.close()

    if milk_total is None:
        milk_total = 0

    ctk.CTkLabel(
        card1,
        text=f"{milk_total} L",
        font=("Arial", 28, "bold")
    ).pack()

    # Revenue
    card2 = ctk.CTkFrame(cards_frame, width=200, height=120)
    card2.pack(side="left", padx=20)

    ctk.CTkLabel(
        card2,
        text="💰 Revenue",
        font=("Arial", 18)
    ).pack(pady=10)

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()

    cur.execute("SELECT SUM(amount) FROM milk")
    revenue = cur.fetchone()[0]

    conn.close()

    if revenue is None:
        revenue = 0

    ctk.CTkLabel(
        card2,
        text=f"₹{revenue}",
        font=("Arial", 28, "bold")
    ).pack()

    # Farmers
    card3 = ctk.CTkFrame(cards_frame, width=200, height=120)
    card3.pack(side="left", padx=20)

    ctk.CTkLabel(
        card3,
        text="👨‍🌾 Farmers",
        font=("Arial", 18)
    ).pack(pady=10)

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM members")
    farmers = cur.fetchone()[0]

    conn.close()

    ctk.CTkLabel(
        card3,
        text=f"{farmers}",
        font=("Arial", 28, "bold")
    ).pack()

# =========================================================
# MILK ENTRY PAGE
# =========================================================

def open_milk_entry():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Milk Entry",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

    form = ctk.CTkFrame(content)
    form.pack(pady=20)

    date = ctk.CTkEntry(form, placeholder_text="Date")
    date.pack(pady=10)

    farmer = ctk.CTkEntry(form, placeholder_text="Farmer ID")
    farmer.pack(pady=10)

    milk = ctk.CTkEntry(form, placeholder_text="Milk")
    milk.pack(pady=10)

    fat = ctk.CTkEntry(form, placeholder_text="Fat")
    fat.pack(pady=10)

    snf = ctk.CTkEntry(form, placeholder_text="SNF")
    snf.pack(pady=10)

    result = ctk.CTkLabel(form, text="")
    result.pack(pady=10)

    def save_entry():

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        f = round(float(fat.get()),1)
        s = int(float(snf.get()))

        cur.execute(
            "SELECT rate FROM rate_chart WHERE fat=? AND snf=?",
            (f, s)
        )

        r = cur.fetchone()

        if r:
            rate = float(r[0])
        else:
            rate = 0

        amount = float(milk.get()) * rate

        cur.execute("""
        INSERT INTO milk(
            date,
            shift,
            member_id,
            milk,
            fat,
            snf,
            rate,
            amount
        )
        VALUES (?,?,?,?,?,?,?,?)
        """, (
            date.get(),
            "Morning",
            farmer.get(),
            milk.get(),
            fat.get(),
            snf.get(),
            rate,
            amount
        ))

        conn.commit()
        conn.close()

        result.configure(
            text=f"Rate: {rate} | Amount: {amount}"
        )

    ctk.CTkButton(
        form,
        text="Save Entry",
        command=save_entry
    ).pack(pady=20)

# =========================================================
# FARMERS PAGE
# =========================================================

def open_farmers():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Farmers",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

    form = ctk.CTkFrame(content)
    form.pack(pady=20)

    name = ctk.CTkEntry(form, placeholder_text="Farmer Name")
    name.pack(pady=10)

    phone = ctk.CTkEntry(form, placeholder_text="Phone")
    phone.pack(pady=10)

    village = ctk.CTkEntry(form, placeholder_text="Village")
    village.pack(pady=10)

    def add_farmer():

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        cur.execute("""
        INSERT INTO members(
            name,
            phone,
            address,
            village,
            joining_date
        )
        VALUES (?,?,?,?,?)
        """, (
            name.get(),
            phone.get(),
            "",
            village.get(),
            datetime.now().strftime("%d-%m-%Y")
        ))

        conn.commit()
        conn.close()

    ctk.CTkButton(
        form,
        text="Add Farmer",
        command=add_farmer
    ).pack(pady=20)

# =========================================================
# RATE CHART PAGE
# =========================================================

def open_rate_chart():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Rate Chart",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

    top_frame = ctk.CTkFrame(content)
    top_frame.pack(fill="x", padx=20, pady=10)

    min_fat = ctk.CTkEntry(top_frame, placeholder_text="Min Fat")
    min_fat.pack(side="left", padx=10)
    min_fat.insert(0, "3.0")

    max_fat = ctk.CTkEntry(top_frame, placeholder_text="Max Fat")
    max_fat.pack(side="left", padx=10)
    max_fat.insert(0, "10.0")

    min_snf = ctk.CTkEntry(top_frame, placeholder_text="Min SNF")
    min_snf.pack(side="left", padx=10)
    min_snf.insert(0, "28")

    max_snf = ctk.CTkEntry(top_frame, placeholder_text="Max SNF")
    max_snf.pack(side="left", padx=10)
    max_snf.insert(0, "32")

    table_frame = ctk.CTkFrame(content)
    table_frame.pack(expand=True, fill="both", padx=20, pady=20)

    tree = ttk.Treeview(table_frame, show="headings")
    tree.pack(expand=True, fill="both")

    def generate_chart():

        tree.delete(*tree.get_children())

        min_f = float(min_fat.get())
        max_f = float(max_fat.get())

        min_s = int(min_snf.get())
        max_s = int(max_snf.get())

        cols = ["FAT"] + [str(i) for i in range(min_s, max_s + 1)]

        tree["columns"] = cols

        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=80, anchor="center")

        fat = min_f

        while fat <= max_f:

            row = [round(fat, 1)] + [0] * (max_s - min_s + 1)

            tree.insert("", "end", values=row)

            fat += 0.1

    def edit_cell(event):

        region = tree.identify("region", event.x, event.y)

        if region != "cell":
            return

        row_id = tree.identify_row(event.y)
        column = tree.identify_column(event.x)

        if not row_id:
            return

        col_index = int(column.replace("#", "")) - 1

        if col_index == 0:
            return

        x, y, width, height = tree.bbox(row_id, column)

        value = tree.set(row_id, column)

        entry = tk.Entry(tree)

        entry.place(x=x, y=y, width=width, height=height)

        entry.insert(0, value)

        entry.focus()

        def save_edit(e):

            try:
                new_val = float(entry.get())
            except:
                entry.destroy()
                return

            tree.set(row_id, column, new_val)

            entry.destroy()

        entry.bind("<Return>", save_edit)

    tree.bind("<Double-1>", edit_cell)

    def save_chart():

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        cur.execute("DELETE FROM rate_chart")

        for item in tree.get_children():

            values = tree.item(item)["values"]

            fat = values[0]

            for i in range(1, len(values)):

                snf = int(tree["columns"][i])

                rate = values[i]

                cur.execute(
                    "INSERT INTO rate_chart VALUES (?,?,?)",
                    (fat, snf, rate)
                )

        conn.commit()
        conn.close()

    btn_frame = ctk.CTkFrame(content)
    btn_frame.pack(fill="x", padx=20, pady=10)

    ctk.CTkButton(
        btn_frame,
        text="Generate Chart",
        command=generate_chart
    ).pack(side="left", padx=10)

    ctk.CTkButton(
        btn_frame,
        text="Save Chart",
        command=save_chart
    ).pack(side="left", padx=10)

# =========================================================
# LEDGER PAGE
# =========================================================

def open_ledger():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Ledger",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

# =========================================================
# PAYMENTS PAGE
# =========================================================

def open_payments():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Payments",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

# =========================================================
# REPORTS PAGE
# =========================================================

def open_reports():

    clear_content()

    heading = ctk.CTkLabel(
        content,
        text="Reports",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

# =========================================================
# SIDEBAR BUTTONS
# =========================================================

buttons = [

    ("🏠 Dashboard", open_dashboard),

    ("🥛 Milk Entry", open_milk_entry),

    ("👨‍🌾 Farmers", open_farmers),

    ("📈 Rate Chart", lambda: rate_chart.open_rate_chart(content)),

    ("📒 Ledger", open_ledger),

    ("💰 Payments", open_payments),

    ("📋 Reports", open_reports),

]

for text, cmd in buttons:

    ctk.CTkButton(
        sidebar,
        text=text,
        command=cmd,
        height=45
    ).pack(
        fill="x",
        padx=15,
        pady=8
    )

# =========================================================
# DEFAULT PAGE
# =========================================================

open_dashboard()

# =========================================================
# RUN APP
# =========================================================

app.mainloop()
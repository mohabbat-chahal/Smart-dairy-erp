import customtkinter as ctk
import sqlite3
import matplotlib.pyplot as plt


def open_dashboard():

    win = ctk.CTkToplevel()
    win.geometry("900x500")
    win.title("Dashboard")

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()

    cur.execute("SELECT SUM(milk) FROM milk")
    total_milk = cur.fetchone()[0] or 0

    cur.execute("SELECT SUM(amount) FROM milk")
    total_amount = cur.fetchone()[0] or 0

    cur.execute("SELECT COUNT(*) FROM members")
    total_farmers = cur.fetchone()[0]

    conn.close()

    # -------- CARDS --------
    cards = ctk.CTkFrame(win)
    cards.pack(fill="x", pady=20)

    ctk.CTkLabel(
        cards,
        text=f"🥛 Total Milk\n{total_milk}",
        font=("Arial", 18)
    ).pack(side="left", padx=20)

    ctk.CTkLabel(
        cards,
        text=f"💰 Revenue\n₹{total_amount}",
        font=("Arial", 18)
    ).pack(side="left", padx=20)

    ctk.CTkLabel(
        cards,
        text=f"👨‍🌾 Farmers\n{total_farmers}",
        font=("Arial", 18)
    ).pack(side="left", padx=20)

    def show_graph():

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        cur.execute("""
        SELECT date, SUM(milk)
        FROM milk
        GROUP BY date
        """)

        data = cur.fetchall()
        conn.close()

        if not data:
            return

        dates = [x[0] for x in data]
        milk = [x[1] for x in data]

        plt.figure(figsize=(8,4))
        plt.plot(dates, milk, marker='o')

        plt.title("Daily Milk Collection")
        plt.xlabel("Date")
        plt.ylabel("Milk")

        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()

    ctk.CTkButton(
        win,
        text="Show Graph",
        command=show_graph
    ).pack(pady=20)
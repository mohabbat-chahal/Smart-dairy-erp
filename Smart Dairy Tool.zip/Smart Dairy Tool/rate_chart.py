import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
import sqlite3


def open_rate_chart(content):

    # =====================================================
    # CLEAR OLD CONTENT
    # =====================================================

    for widget in content.winfo_children():
        widget.destroy()

    # =====================================================
    # HEADING
    # =====================================================

    heading = ctk.CTkLabel(
        content,
        text="Rate Chart",
        font=("Arial", 28, "bold")
    )
    heading.pack(pady=20)

    # =====================================================
    # TOP CONTROLS
    # =====================================================

    top_frame = ctk.CTkFrame(content)
    top_frame.pack(fill="x", padx=20, pady=10)

    # Min Fat
    min_fat = ctk.CTkEntry(
        top_frame,
        placeholder_text="Min Fat",
        width=100
    )
    min_fat.pack(side="left", padx=10)
    min_fat.insert(0, "3.0")

    # Max Fat
    max_fat = ctk.CTkEntry(
        top_frame,
        placeholder_text="Max Fat",
        width=100
    )
    max_fat.pack(side="left", padx=10)
    max_fat.insert(0, "10.0")

    # Min SNF
    min_snf = ctk.CTkEntry(
        top_frame,
        placeholder_text="Min SNF",
        width=100
    )
    min_snf.pack(side="left", padx=10)
    min_snf.insert(0, "28")

    # Max SNF
    max_snf = ctk.CTkEntry(
        top_frame,
        placeholder_text="Max SNF",
        width=100
    )
    max_snf.pack(side="left", padx=10)
    max_snf.insert(0, "32")

    # =====================================================
    # TABLE FRAME
    # =====================================================

    table_frame = ctk.CTkFrame(content)
    table_frame.pack(
        expand=True,
        fill="both",
        padx=20,
        pady=20
    )

    # Scrollbars
    y_scroll = ttk.Scrollbar(table_frame)
    y_scroll.pack(side="right", fill="y")

    x_scroll = ttk.Scrollbar(
        table_frame,
        orient="horizontal"
    )
    x_scroll.pack(side="bottom", fill="x")

    # Treeview
    tree = ttk.Treeview(
        table_frame,
        show="headings",
        yscrollcommand=y_scroll.set,
        xscrollcommand=x_scroll.set
    )

    tree.pack(expand=True, fill="both")

    y_scroll.config(command=tree.yview)
    x_scroll.config(command=tree.xview)

    # =====================================================
    # GENERATE CHART
    # =====================================================

    def generate_chart():

        tree.delete(*tree.get_children())

        min_f = float(min_fat.get())
        max_f = float(max_fat.get())

        min_s = int(min_snf.get())
        max_s = int(max_snf.get())

        cols = ["FAT"]

        for i in range(min_s, max_s + 1):
            cols.append(str(i))

        tree["columns"] = cols

        # Configure Columns
        for c in cols:

            tree.heading(c, text=c)

            tree.column(
                c,
                width=90,
                anchor="center"
            )

        # Generate Rows
        fat = min_f

        while fat <= max_f:

            row = [round(fat, 1)]

            for i in range(min_s, max_s + 1):
                row.append(0)

            tree.insert("", "end", values=row)

            fat += 0.1

    # =====================================================
    # EDIT CELL
    # =====================================================

    def edit_cell(event):

        region = tree.identify("region", event.x, event.y)

        if region != "cell":
            return

        row_id = tree.identify_row(event.y)

        column = tree.identify_column(event.x)

        if not row_id:
            return

        col_index = int(column.replace("#", "")) - 1

        # FAT COLUMN LOCK
        if col_index == 0:
            return

        x, y, width, height = tree.bbox(
            row_id,
            column
        )

        value = tree.set(row_id, column)

        entry = tk.Entry(tree)

        entry.place(
            x=x,
            y=y,
            width=width,
            height=height
        )

        entry.insert(0, value)

        entry.focus()

        # =================================================
        # SAVE & MOVE NEXT
        # =================================================

        def save_edit(e):

            try:
                new_val = float(entry.get())
            except:
                entry.destroy()
                return

            # Save Value
            tree.set(row_id, column, new_val)

            entry.destroy()

            # =============================================
            # MOVE NEXT CELL
            # =============================================

            cols = tree["columns"]

            next_col_index = col_index + 1

            # SAME ROW
            if next_col_index < len(cols):

                next_column = f"#{next_col_index + 1}"

                bbox = tree.bbox(
                    row_id,
                    next_column
                )

                if bbox:

                    nx, ny, nw, nh = bbox

                    fake_event = type(
                        "Event",
                        (),
                        {
                            "x": nx + 5,
                            "y": ny + 5
                        }
                    )

                    edit_cell(fake_event)

            # NEXT ROW
            else:

                next_item = tree.next(row_id)

                if next_item:

                    next_column = "#2"

                    bbox = tree.bbox(
                        next_item,
                        next_column
                    )

                    if bbox:

                        nx, ny, nw, nh = bbox

                        fake_event = type(
                            "Event",
                            (),
                            {
                                "x": nx + 5,
                                "y": ny + 5
                            }
                        )

                        edit_cell(fake_event)

        entry.bind("<Return>", save_edit)

    tree.bind("<Double-1>", edit_cell)

    # =====================================================
    # SAVE CHART
    # =====================================================

    def save_chart():

        conn = sqlite3.connect("dairy.db")

        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS rate_chart(
            fat REAL,
            snf REAL,
            rate REAL
        )
        """)

        # CLEAR OLD
        cur.execute("DELETE FROM rate_chart")

        # INSERT NEW
        for item in tree.get_children():

            values = tree.item(item)["values"]

            fat = values[0]

            for i in range(1, len(values)):

                snf = int(tree["columns"][i])

                rate = values[i]

                cur.execute(
                    "INSERT INTO rate_chart VALUES (?,?,?)",
                    (fat, snf, rate)
                )

        conn.commit()

        conn.close()

    # =====================================================
    # BUTTONS
    # =====================================================

    btn_frame = ctk.CTkFrame(content)
    btn_frame.pack(fill="x", padx=20, pady=10)

    ctk.CTkButton(
        btn_frame,
        text="Generate Chart",
        command=generate_chart
    ).pack(side="left", padx=10)

    ctk.CTkButton(
        btn_frame,
        text="Save Chart",
        command=save_chart
    ).pack(side="left", padx=10)
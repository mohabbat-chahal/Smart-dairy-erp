import sqlite3

def add_farmer(name, phone, address):
    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO farmers(name, phone, address) VALUES (?,?,?)",
                (name, phone, address))
    conn.commit()
    conn.close()

def get_farmers():
    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()
    cur.execute("SELECT farmer_id, name FROM farmers")
    rows = cur.fetchall()
    conn.close()
    return [f"{r[0]} - {r[1]}" for r in rows]
import shutil
import datetime

def backup_data():
    name = "backup_" + str(datetime.date.today()) + ".db"
    shutil.copy("dairy.db", name)
import tkinter as tk
from tkinter import ttk
import sqlite3

def open_payment():

    win = tk.Toplevel()
    win.title("Payments")
    win.geometry("600x450")

    # -------- INPUT --------
    tk.Label(win, text="Farmer ID").pack()
    member = tk.Entry(win)
    member.pack()

    tk.Label(win, text="Amount").pack()
    amount = tk.Entry(win)
    amount.pack()

    tk.Label(win, text="Date").pack()
    date = tk.Entry(win)
    date.pack()

    # -------- SAVE --------
    def save():
        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER,
            amount REAL,
            date TEXT
        )
        """)

        cur.execute("INSERT INTO payments(member_id, amount, date) VALUES (?,?,?)",
                    (member.get(), amount.get(), date.get()))

        conn.commit()
        conn.close()

        load()

    tk.Button(win, text="Save Payment", command=save).pack(pady=10)

    # -------- TABLE --------
    tree = ttk.Treeview(win, show="headings")
    tree.pack(fill="both", expand=True)

    tree["columns"] = ("ID","Farmer","Amount","Date")

    for col in tree["columns"]:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    # -------- LOAD --------
    def load():
        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM payments")
        rows = cur.fetchall()
        conn.close()

        tree.delete(*tree.get_children())

        for r in rows:
            tree.insert("", "end", values=r)

    load()
from reportlab.pdfgen import canvas

def print_receipt(record):

    file = "receipt.pdf"
    c = canvas.Canvas(file)

    c.setFont("Helvetica", 12)

    c.drawString(100, 750, "Milk Receipt")

    labels = ["ID","Date","Farmer","Milk","Fat","SNF","Rate","Amount"]

    y = 700
    for i in range(len(labels)):
        c.drawString(100, y, f"{labels[i]}: {record[i]}")
        y -= 25

    c.save()
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet


# -------- GET FARMERS FOR DROPDOWN --------
def get_farmers():
    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()
    cur.execute("SELECT id, name FROM members")
    data = cur.fetchall()
    conn.close()
    return [f"{r[0]} - {r[1]}" for r in data]


# -------- MAIN LEDGER WINDOW --------
def open_ledger():

    win = tk.Toplevel()
    win.title("Farmer Ledger (Professional)")
    win.geometry("950x600")

    # -------- TOP FRAME --------
    top = tk.Frame(win)
    top.pack(pady=10)

    tk.Label(top, text="Select Farmer:", font=("Arial", 12)).pack(side="left")

    farmer_dropdown = ttk.Combobox(top, values=get_farmers(), width=30)
    farmer_dropdown.pack(side="left", padx=10)

    # -------- TABLE --------
    tree = ttk.Treeview(win, show="headings")
    tree.pack(fill="both", expand=True)

    cols = ["Date", "Milk Amount", "Payment", "Balance"]
    tree["columns"] = cols

    for c in cols:
        tree.heading(c, text=c)
        tree.column(c, width=150, anchor="center")

    # -------- TOTAL PANEL --------
    total_frame = tk.Frame(win)
    total_frame.pack(pady=10)

    total_label = tk.Label(total_frame, text="", font=("Arial", 12, "bold"))
    total_label.pack()

    # -------- LOAD LEDGER --------
    def load_ledger():

        selected = farmer_dropdown.get()
        if not selected:
            messagebox.showwarning("Select Farmer", "Please select a farmer")
            return

        farmer_id = selected.split(" - ")[0]

        tree.delete(*tree.get_children())

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        # Milk data
        cur.execute("SELECT date, amount FROM milk WHERE member_id=?", (farmer_id,))
        milk_data = cur.fetchall()

        # Payment data
        cur.execute("SELECT date, amount FROM payments WHERE member_id=?", (farmer_id,))
        payment_data = cur.fetchall()

        conn.close()

        # Combine
        records = []

        for m in milk_data:
            records.append((m[0], m[1], 0))

        for p in payment_data:
            records.append((p[0], 0, p[1]))

        records.sort(key=lambda x: x[0])

        balance = 0
        total_milk = 0
        total_payment = 0

        ledger_rows = []

        for r in records:
            date, milk_amt, pay = r

            balance += milk_amt - pay
            total_milk += milk_amt
            total_payment += pay

            tree.insert("", "end", values=(date, milk_amt, pay, balance))
            ledger_rows.append([date, milk_amt, pay, balance])

        total_label.config(
            text=f"Total Milk Amount: {total_milk}   |   Paid: {total_payment}   |   Balance: {balance}"
        )

        return ledger_rows, selected

    # -------- PRINT FUNCTION --------
    def print_ledger():

        result = load_ledger()
        if not result:
            return

        rows, farmer_name = result

        if not rows:
            messagebox.showinfo("No Data", "No ledger data available")
            return

        file = f"{farmer_name}_ledger.pdf"

        doc = SimpleDocTemplate(file)
        styles = getSampleStyleSheet()

        title = Paragraph(f"Ledger Report - {farmer_name}", styles["Title"])

        table_data = [["Date", "Milk Amount", "Payment", "Balance"]] + rows

        table = Table(table_data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.grey),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('GRID', (0,0), (-1,-1), 1, colors.black),
            ('ALIGN', (1,1), (-1,-1), 'CENTER')
        ]))

        doc.build([title, table])

        messagebox.showinfo("Success", f"Ledger printed: {file}")

    # -------- BUTTONS --------
    btn_frame = tk.Frame(win)
    btn_frame.pack(pady=10)

    tk.Button(btn_frame, text="Show Ledger", command=load_ledger).pack(side="left", padx=5)
    tk.Button(btn_frame, text="Print Ledger", command=print_ledger).pack(side="left", padx=5)
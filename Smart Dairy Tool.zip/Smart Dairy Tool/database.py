import sqlite3

def connect_db():

    conn = sqlite3.connect("dairy.db")

    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS members(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone TEXT,
        address TEXT,
        village TEXT,
        joining_date TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS milk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        shift TEXT,
        member_id INTEGER,
        milk REAL,
        fat REAL,
        snf REAL,
        rate REAL,
        amount REAL
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS rate_chart(
        fat REAL,
        snf REAL,
        rate REAL
    )
    """)

    conn.commit()

    conn.close()
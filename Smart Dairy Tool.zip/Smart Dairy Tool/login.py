import customtkinter as ctk
import sqlite3
import main

ctk.set_appearance_mode("light")

app = ctk.CTk()
app.geometry("400x300")
app.title("Dairy Login")


def login():

    user = username.get()
    pwd = password.get()

    conn = sqlite3.connect("dairy.db")
    cur = conn.cursor()

    cur.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (user, pwd)
    )

    result = cur.fetchone()

    conn.close()

    if result:
        app.destroy()
        main.run_main()
    else:
        status.configure(text="Invalid Login")


ctk.CTkLabel(
    app,
    text="Smart Dairy Login",
    font=("Arial", 22, "bold")
).pack(pady=20)

username = ctk.CTkEntry(app, placeholder_text="Username")
username.pack(pady=10)

password = ctk.CTkEntry(
    app,
    placeholder_text="Password",
    show="*"
)
password.pack(pady=10)

ctk.CTkButton(
    app,
    text="Login",
    command=login
).pack(pady=20)

status = ctk.CTkLabel(app, text="")
status.pack()

app.mainloop()
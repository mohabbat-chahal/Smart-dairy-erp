import tkinter as tk
from tkinter import ttk
import sqlite3
import receipt_module

def open_records():

    win = tk.Toplevel()
    win.title("Milk Records")
    win.geometry("900x500")

    # -------- FILTER --------
    frame = tk.Frame(win)
    frame.pack(pady=10)

    tk.Label(frame, text="Date (YYYY-MM-DD)").pack(side="left")

    date_entry = tk.Entry(frame)
    date_entry.pack(side="left")

    # -------- TABLE --------
    tree = ttk.Treeview(win, show="headings")
    tree.pack(fill="both", expand=True)

    cols = ["ID","Date","Farmer","Milk","Fat","SNF","Rate","Amount"]
    tree["columns"] = cols

    for c in cols:
        tree.heading(c, text=c)
        tree.column(c, width=100)

    # -------- LOAD DATA --------
    def load(date=None):

        tree.delete(*tree.get_children())

        conn = sqlite3.connect("dairy.db")
        cur = conn.cursor()

        if date:
            cur.execute("SELECT * FROM milk WHERE date=?", (date,))
        else:
            cur.execute("SELECT * FROM milk")

        rows = cur.fetchall()
        conn.close()

        for r in rows:
            tree.insert("", "end", values=r)

    def search():
        load(date_entry.get())

    tk.Button(frame, text="Search", command=search).pack(side="left", padx=5)
    tk.Button(frame, text="Show All", command=lambda: load()).pack(side="left")

    # -------- PRINT RECEIPT --------
    def print_selected():
        selected = tree.selection()
        if not selected:
            return

        record = tree.item(selected[0])["values"]
        receipt_module.print_receipt(record)

    tk.Button(win, text="Print Receipt", command=print_selected).pack(pady=5)

    load()